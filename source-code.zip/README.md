# 518_assignment_2

the link of the website hosted : 44.202.40.217:3000 <br/>
hosted by aws EC2 
*please ignore my-client outside Source-code as i cloned it duplicated 
thank you 
recorded video : https://albany.zoom.us/rec/share/IUK6HZ_AkSIhRXR1ZEiZc6nGY3S3jW-LA9vx_fKWkt5M833MjT0mQZ8WRFusLMWn.mVG1MUnkid8PpcdW?startTime=1665363058000
Passcode: 5G.0$Mah
